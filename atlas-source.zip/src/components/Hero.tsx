"use client";

import { motion } from "framer-motion";
import { ArrowRight, ChevronRight, Terminal } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect, useRef } from "react";

// Bank/Client Logos
const allPartners = [
  { name: "CBE", src: "/bank/act.png" }, // Placeholder if needed
  { name: "Ethio Telecom", src: "/bank/Ethio-Telecom.jpg" },
  { name: "Dashen Bank", src: "/bank/dashen.jpeg" },
  { name: "Bunna Bank", src: "/bank/bunna.png" },
  { name: "Awash", src: "/bank/birhan.png" },
  { name: "Wegagen", src: "/bank/wegagen.png" },
  { name: "Nib", src: "/bank/nib.png" },
  { name: "Enat", src: "/bank/enat.png" },
  { name: "Oromia Bank", src: "/bank/oromo.png" },
  { name: "Sinque Bank", src: "/bank/sinque.png" },
  { name: "Hijra Bank", src: "/bank/hijira.jpeg" },
  { name: "Addis Bank", src: "/bank/addis.jpeg" },
];

export default function Hero() {
  const [terminalLines, setTerminalLines] = useState<Array<{ text: string; color: string; id: number; isCommand?: boolean }>>([]);
  const [currentCommand, setCurrentCommand] = useState("");
  const [stepIndex, setStepIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const steps = [
    { text: "act init infrastructure", type: "command" },
    { text: "Initializing secure environment...", type: "output", color: "text-neutral-500" },
    { text: "✓ Core banking systems connected", type: "output", color: "text-primary-400" },
    { text: "✓ Enterprise security protocols active", type: "output", color: "text-primary-400" },
    
    { text: "act security --scan --compliance pci-dss", type: "command" },
    { text: "Running vulnerability assessment...", type: "output", color: "text-neutral-500" },
    { text: "✓ PCI-DSS Compliance: VERIFIED", type: "output", color: "text-emerald-400" },
    { text: "✓ Firewall rules updated", type: "output", color: "text-emerald-400" },

    { text: "act build --service uni-cash-mobile", type: "command" },
    { text: "Compiling mobile banking module...", type: "output", color: "text-neutral-500" },
    { text: "✓ Build successful (1.2s)", type: "output", color: "text-secondary-400" },
    
    { text: "act provision --cloud hybrid", type: "command" },
    { text: "Provisioning hybrid cloud resources...", type: "output", color: "text-neutral-500" },
    { text: "✓ Data center sync complete", type: "output", color: "text-primary-400" },
    { text: "✓ Latency optimized: < 5ms", type: "output", color: "text-primary-400" },

    { text: "act integrate --partner ethio-telecom", type: "command" },
    { text: "Establishing secure API gateway...", type: "output", color: "text-neutral-500" },
    { text: "✓ Payment channel active", type: "output", color: "text-secondary-400" },

    { text: "act deploy --prod --rolling-update", type: "command" },
    { text: "Deploying to production nodes...", type: "output", color: "text-neutral-500" },
    { text: "✓ Service merchant-gateway: ONLINE", type: "output", color: "text-emerald-400" },
    { text: "✓ Service vib-core: ONLINE", type: "output", color: "text-emerald-400" },

    { text: "act monitor --realtime", type: "command" },
    { text: "System status: HEALTHY", type: "output", color: "text-emerald-400" },
    { text: "Uptime: 99.999%", type: "output", color: "text-emerald-400" },
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [terminalLines, currentCommand]);

  useEffect(() => {
    if (stepIndex >= steps.length) {
      const timeout = setTimeout(() => {
        setTerminalLines([]);
        setStepIndex(0);
        setCharIndex(0);
      }, 5000);
      return () => clearTimeout(timeout);
    }

    const currentStep = steps[stepIndex];

    if (currentStep.type === "command") {
      if (charIndex < currentStep.text.length) {
        const timeout = setTimeout(() => {
          setCurrentCommand((prev) => prev + currentStep.text[charIndex]);
          setCharIndex((prev) => prev + 1);
        }, 50 + Math.random() * 50);
        return () => clearTimeout(timeout);
      } else {
        const timeout = setTimeout(() => {
          setTerminalLines((prev) => [
            ...prev,
            { text: currentStep.text, color: "text-neutral-300", id: Date.now(), isCommand: true },
          ]);
          setCurrentCommand("");
          setCharIndex(0);
          setStepIndex((prev) => prev + 1);
        }, 500);
        return () => clearTimeout(timeout);
      }
    } else {
      const timeout = setTimeout(() => {
        setTerminalLines((prev) => [
          ...prev,
          { text: currentStep.text, color: currentStep.color || "text-neutral-400", id: Date.now(), isCommand: false },
        ]);
        setStepIndex((prev) => prev + 1);
      }, 400);
      return () => clearTimeout(timeout);
    }
  }, [stepIndex, charIndex]);

  return (
    <section className="relative w-[95%] mx-auto min-h-[90vh] flex flex-col justify-center overflow-hidden bg-white">
      {/* Background Gradients - Neon Inspired */}
    

      <div className="container relative mx-auto px-6 z-10 pt-12 lg:pt-0">
        <div className="grid lg:grid-cols-[45%_45%] gap-12 lg:gap-20 items-center">
          
          {/* Left Column: Content */}
          <div className="flex flex-col items-start text-left">
            {/* Badge */}
         

            {/* Main Heading */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="text-5xl md:text-6xl font-bold tracking-tight text-neutral-900 leading-[1.1] mb-8 font-display"
            >
              The Digital Backbone <br />
              <span className="relative inline-block bg-transparent px-2 py-1 text-(--steel-blue)">
                <span className="relative">
                  for Modern Ethiopia
                </span>
              </span>
            </motion.h1>

            {/* Subheading */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg md:text-xl text-neutral-500 mb-10 leading-relaxed max-w-xl font-light"
            >
              Atlas Computer Technology PLC (ACT) is a premier ICT solutions provider in Addis Ababa, delivering infrastructure, system integration, software development, and consultancy services for over a decade.
            </motion.p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center gap-4"
            >
              <Link
                href="#contact"
                className="group relative inline-flex items-center justify-center px-8 py-4 text-white bg-primary-600 rounded-md overflow-hidden transition-all hover:bg-primary-700 shadow-xl shadow-primary-600/20 hover:shadow-primary-600/30 hover:-translate-y-1"
              >
                <span className="font-semibold text-lg">Start Your Project</span>
                <ArrowRight className="ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
              </Link>
              
              <Link
                href="#services"
                className="group inline-flex items-center justify-center px-8 py-4 text-primary-600 bg-white border border-primary-200 rounded-md hover:bg-primary-50 hover:border-primary-300 transition-all font-medium text-lg shadow-sm hover:shadow-md"
              >
                View Solutions
              </Link>
            </motion.div>

            {/* Trust Indicators (Logos) */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="mt-12 pt-8 border-t border-neutral-100 w-full"
            >
              <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-4">Trusted by Leading Financial Institutions</p>
              <div className="relative w-full overflow-hidden" style={{ maskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)' }}>
                 <div className="flex gap-12 animate-marquee items-center grayscale opacity-60 hover:grayscale-0 hover:opacity-100 transition-all duration-500 w-max">
                    {[...allPartners, ...allPartners].map((partner, i) => (
                      <div key={i} className="relative w-32 h-16 shrink-0 flex items-center justify-center">
                         <Image 
                           src={partner.src} 
                           alt={partner.name} 
                           width={120} 
                           height={60} 
                           className="object-contain max-h-12 w-auto"
                         />
                      </div>
                    ))}
                 </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Terminal Preview */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4, type: "spring", bounce: 0.2 }}
            className="relative w-full perspective-[2000px]"
          >
            {/* Abstract Decorative Elements behind terminal */}
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-secondary-200/30 rounded-full blur-3xl opacity-20" />
            <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-primary-200/30 rounded-full blur-3xl opacity-20" />
            
            <div className="relative rounded-xl bg-[#1e1e1e] border border-white/10 shadow-2xl shadow-black/50 overflow-hidden h-[480px] flex flex-col transform transition-transform duration-700 ease-out hover:scale-[1.01]">
              {/* Terminal Header */}
              <div className="flex items-center justify-between px-4 py-3 bg-[#252526] border-b border-black/20">
                <div className="flex gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#FF5F56] hover:bg-[#FF5F56]/80 transition-colors shadow-inner"></div>
                  <div className="w-3 h-3 rounded-full bg-[#FFBD2E] hover:bg-[#FFBD2E]/80 transition-colors shadow-inner"></div>
                  <div className="w-3 h-3 rounded-full bg-[#27C93F] hover:bg-[#27C93F]/80 transition-colors shadow-inner"></div>
                </div>
                <div className="flex items-center gap-2 px-3 py-1 rounded-md bg-black/20 border border-white/5">
                  <Terminal size={10} className="text-neutral-500" />
                  <span className="text-[10px] text-neutral-400 font-mono tracking-wide">act-cli — zsh</span>
                </div>
                <div className="w-10"></div>
              </div>

              {/* Terminal Content */}
              <div ref={scrollRef} className="p-6 font-mono text-sm md:text-base text-left overflow-y-auto flex-1 bg-[#1e1e1e] [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                <div className="flex flex-col gap-2">
                  {terminalLines.map((line) => (
                    <div key={line.id} className={`${line.color} ${line.isCommand ? "" : "pl-4"}`}>
                      {line.isCommand ? (
                        <div className="flex items-center gap-2">
                          <span className="text-secondary-400 font-bold">➜</span>
                          <span className="text-blue-400 font-bold">~</span>
                          <span className="text-neutral-200">{line.text}</span>
                        </div>
                      ) : (
                        line.text
                      )}
                    </div>
                  ))}
                  
                  {/* Active typing line */}
                  {stepIndex < steps.length && steps[stepIndex].type === 'command' && (
                    <div className="flex items-center gap-2 text-neutral-400">
                      <span className="text-secondary-400 font-bold">➜</span>
                      <span className="text-blue-400 font-bold">~</span>
                      <span className="text-neutral-200">{currentCommand}</span>
                      <span className="animate-pulse bg-neutral-400 w-2.5 h-5 block"></span>
                    </div>
                  )}

                  {/* Final blinking cursor */}
                  {stepIndex >= steps.length && (
                    <div className="flex items-center gap-2 text-neutral-400 mt-2">
                      <span className="text-secondary-400 font-bold">➜</span>
                      <span className="text-blue-400 font-bold">~</span>
                      <span className="text-neutral-200"></span>
                      <span className="animate-pulse bg-neutral-400 w-2.5 h-5 block"></span>
                    </div>
                  )}
                </div>
              </div>

              {/* Status Bar */}
              <div className="px-3 py-1.5 bg-[#007acc] text-white text-[10px] font-mono flex justify-between items-center select-none">
                 <div className="flex gap-3">
                    <span className="flex items-center gap-1"><span className="font-bold">NORMAL</span></span>
                    <span>master*</span>
                 </div>
                 <div className="flex gap-3">
                    <span>utf-8</span>
                    <span>Ln {terminalLines.length + 1}, Col 1</span>
                    <span className="flex items-center gap-1.5">ACT-SERVER <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span></span>
                 </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
